package com.example.crime.database

import androidx.room.Dao
import androidx.room.Query
import com.example.crime.Crime
import java.util.*

@Dao
interface CrimeDAO{

    @Query("Select * from crime")
    fun getCrimes(): List<Crime>

    @Query("Select * from crime where id=(:id)")
    fun getCrime(id: UUID): Crime?

}